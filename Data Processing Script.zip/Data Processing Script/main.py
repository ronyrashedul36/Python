import csv

INPUT_FILE = 'sales_data.csv'

OUTPUT_FILE = 'sales_report.txt'

def process_sales_data(input_filename):
    total_units_sold = 0

    total_revenue = 0

    transaction_count = 0

    try:
        with open(input_filename, mode='r') as csv_file:

            csv_reader = csv.DictReader(csv_file)

            for row in csv_reader:
                try:
                    units_sold = int(row['UnitsSold'])
                    price_per_unit = float(row['PricePerUnit'])

                    total_units_sold += units_sold
                    total_revenue += units_sold * price_per_unit
                    transaction_count += 1

                except (ValueError, KeyError) as e:
                    print(f"skipping a row due to bad data: {row}. Error: {e}")
    except FileNotFoundError:
        print(f"Error: The file {input_filename} was not found")
        return None
    if transaction_count > 0:
        average_revenue = total_revenue / transaction_count
    else:
        average_revenue = 0

    report_data = {
        'total_units_sold' : total_units_sold,
        'total_revenue' : total_revenue,
        'average_revenue' : average_revenue,
        'transaction_count' : transaction_count
    }

    return report_data

def write_report(report_data, output_filename):
    if report_data is None:
        print("Report generation failed because data processing failed.")
        return

    with open(output_filename, mode='w') as report_file:
        report_file.write("---Sales Analysis Report ---\n")
        report_file.write("="*31+"\n\n")
        report_file.write(f'Total Transactions Processed: {report_data["transaction_count"]}')
        report_file.write(f"Total units Sold: {report_data['total_units_sold']}")
        report_file.write(f"Total Revenue: ${report_data['total_revenue']:.2f}\n")
        report_file.write(f"Average Revenue Per Transaction: ${report_data['average_revenue']:.2f}\n")
    print(f"Report successfully generated and saved to {output_filename}")

def main():
    processed_data = process_sales_data(INPUT_FILE)
    write_report(processed_data, OUTPUT_FILE)


if __name__ == "__main__":
    main()