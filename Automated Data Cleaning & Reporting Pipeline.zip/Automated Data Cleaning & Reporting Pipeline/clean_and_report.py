import pandas as pd


def clean_customer_data(df: pd.DataFrame) -> pd.DataFrame:
    """
    Cleans the customer DataFrame by handling duplicates, missing values,
    and inconsistent data formats.

    Args:
        df (pd.DataFrame): The raw, dirty DataFrame.

    Returns:
        pd.DataFrame: The cleaned DataFrame.
    """
    print("--- Starting Data Cleaning Process ---")

    # 1. Handle Duplicate Rows
    initial_rows = len(df)
    df.drop_duplicates(inplace=True)
    print(f"Step 1: Removed {initial_rows - len(df)} duplicate row(s).")

    # 2. Handle Missing Values
    # Fill missing 'Age' with the median
    median_age = df['Age'].median()
    df['Age'] = df['Age'].fillna(median_age)

    # Fill missing 'LastPurchaseAmount' with the mean, as it's a monetary value
    mean_purchase = df['LastPurchaseAmount'].mean()
    df['LastPurchaseAmount'] = df['LastPurchaseAmount'].fillna(mean_purchase)
    print("Step 2: Filled missing values in 'Age' and 'LastPurchaseAmount'.")

    # 3. Standardize Text Columns
    # Clean 'Gender' column
    df['Gender'] = df['Gender'].str.strip().str.title()
    # Clean 'City' column
    df['City'] = df['City'].str.strip().str.title()
    print("Step 3: Standardized 'Gender' and 'City' columns.")

    # 4. Standardize Date Column
    # Convert 'SignupDate' to a consistent YYYY-MM-DD format
    df['SignupDate'] = pd.to_datetime(df['SignupDate'], errors='coerce')
    df.dropna(subset=['SignupDate'], inplace=True)  # Drop if conversion fails
    df['SignupDate'] = df['SignupDate'].dt.strftime('%Y-%m-%d')
    print("Step 4: Standardized 'SignupDate' column.")

    # 5. Correct Data Types
    df['Age'] = df['Age'].astype(int)
    print("Step 5: Corrected data types.")

    print("--- Data Cleaning Complete ---")
    return df


def generate_summary_report(df: pd.DataFrame, output_path: str):
    """
    Generates a summary report from the cleaned DataFrame and saves it to a file.

    Args:
        df (pd.DataFrame): The cleaned DataFrame.
        output_path (str): The path to save the report file.
    """
    print(f"--- Generating Summary Report to '{output_path}' ---")

    # Perform Analysis
    total_customers = len(df)
    gender_distribution = df['Gender'].value_counts()
    city_distribution = df['City'].value_counts()
    average_age = df['Age'].mean()
    average_purchase = df['LastPurchaseAmount'].mean()

    # Write the report
    with open(output_path, 'w') as f:
        f.write("--- Customer Data Summary Report ---\n")
        f.write("=" * 35 + "\n\n")

        f.write(f"Total Unique Customers: {total_customers}\n\n")

        f.write("Gender Distribution:\n")
        f.write(gender_distribution.to_string())
        f.write("\n\n")

        f.write("City Distribution:\n")
        f.write(city_distribution.to_string())
        f.write("\n\n")

        f.write("Customer Demographics:\n")
        f.write(f"  - Average Age: {average_age:.1f} years\n")
        f.write(f"  - Average Last Purchase Amount: ${average_purchase:,.2f}\n")

    print("--- Report Generation Complete ---")


# --- Main execution block ---
if __name__ == "__main__":
    # Define file paths
    INPUT_FILE = "dirty_customers.csv"
    CLEAN_OUTPUT_FILE = "clean_customers.csv"
    REPORT_OUTPUT_FILE = "customer_summary_report.txt"

    try:
        # Load the raw data
        raw_df = pd.read_csv(INPUT_FILE)

        # Clean the data using our function
        clean_df = clean_customer_data(raw_df)

        # Save the cleaned data to a new CSV
        clean_df.to_csv(CLEAN_OUTPUT_FILE, index=False)
        print(f"\nClean data successfully saved to '{CLEAN_OUTPUT_FILE}'")

        # Generate the summary report from the cleaned data
        generate_summary_report(clean_df, REPORT_OUTPUT_FILE)

    except FileNotFoundError:
        print(f"\nError: The input file '{INPUT_FILE}' was not found.")
    except Exception as e:
        print(f"\nAn unexpected error occurred: {e}")