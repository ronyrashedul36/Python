import pandas as pd


def analyze_hr_data(emp_file, dept_file, review_file, proj_file, report_file):
    """
    Loads employee, department, review, and project data, merges them,
    performs departmental analysis, and generates a summary report.
    """
    try:
        # Step 1: Load all datasets
        print("Loading all datasets...")
        df_emp = pd.read_csv(emp_file)
        df_dept = pd.read_csv(dept_file)
        df_rev = pd.read_csv(review_file)
        df_proj = pd.read_csv(proj_file)
        print("All datasets loaded successfully.")

        # Step 2: Pre-process and merge data
        print("Merging and preparing data...")
        # First, calculate total hours worked per employee from the projects data
        # This is a preliminary groupby operation
        employee_hours = df_proj.groupby('EmployeeID')['HoursWorked'].sum().reset_index()

        # Merge employees with their departments
        df_master = pd.merge(df_emp, df_dept, on='DepartmentID', how='left')

        # Merge with performance reviews
        df_master = pd.merge(df_master, df_rev[['EmployeeID', 'PerformanceScore']], on='EmployeeID', how='left')

        # Merge with total hours worked
        df_master = pd.merge(df_master, employee_hours, on='EmployeeID', how='left')

        # Handle potential missing values (e.g., an employee with no project hours)
        df_master['HoursWorked'].fillna(0, inplace=True)
        print("Master DataFrame created successfully.")

        print("\n--- Master DataFrame Head ---")
        print(df_master.head())

        # Step 3: Perform GroupBy Analysis on the master DataFrame
        print("\nPerforming departmental analysis...")

        # a) Calculate average performance score per department
        dept_performance = df_master.groupby('DepartmentName')['PerformanceScore'].mean().round(2).sort_values(
            ascending=False)

        # b) Calculate average hours worked per department
        dept_hours = df_master.groupby('DepartmentName')['HoursWorked'].mean().round(2).sort_values(ascending=False)

        # c) Count the number of employees per department for context
        dept_employee_count = df_master.groupby('DepartmentName')['EmployeeID'].count()
        print("Analysis complete.")

        # Step 4: Generate the Report
        print(f"Generating report to '{report_file}'...")
        with open(report_file, 'w') as f:
            f.write("--- HR Departmental Performance Analysis Report ---\n")
            f.write("=" * 50 + "\n\n")

            f.write("--- Employee Count per Department ---\n")
            f.write(dept_employee_count.to_string())
            f.write("\n\n")

            f.write("--- Average Performance Score per Department (Scale 1-5) ---\n")
            f.write(dept_performance.to_string())
            f.write("\n\n")

            f.write("--- Average Hours Worked per Employee in Each Department ---\n")
            f.write(dept_hours.to_string())
            f.write("\n")

        print("Report generated successfully.")

    except FileNotFoundError as e:
        print(f"Error: File not found - {e.filename}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")


# --- Main execution block ---
if __name__ == "__main__":
    analyze_hr_data(
        emp_file="employees.csv",
        dept_file="departments.csv",
        review_file="reviews.csv",
        proj_file="projects.csv",
        report_file="hr_report.txt"
    )