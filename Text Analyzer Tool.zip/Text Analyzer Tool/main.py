from text_utils.counter import count_words, count_characters

from text_utils.formatter import to_uppercase, reverse_text

print("---Text Analyzer Tool---")

user_text = input("Please enter a sentence or paragraph:\n")

word_count = count_words(user_text)

char_count = count_characters(user_text)

upper_text = to_uppercase(user_text)

reversed_text = reverse_text(user_text)

print("\n---Analysis Report---")

print(f"Total words: {word_count}")

print(f"Total characters (excluding spaces): {char_count}")

print(f"Text in uppercase: {upper_text}")

print(f"Reversed Text: {reversed_text}")