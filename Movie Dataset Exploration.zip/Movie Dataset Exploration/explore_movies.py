import pandas as pd

DATA_FILE = 'imdb.csv'

def explore_movie_dataset(filepath):
    try:
        print(f"Loading dataset from {filepath}")
        df = pd.read_csv(filepath)
        print("Dataset loaded successfully")
        print("\n---Initial Data Overview---")
        print("First 5 rows of the dataset:")
        print(df.head())
        print("\nDataset Info: ")
        df.info()
        print("\n---Cleaning Data---")
        critical_columns = ['Title', 'Genre', 'Year', 'Rating']
        df.dropna(subset=critical_columns, inplace=True)
        df['Year'] = pd.to_numeric(df['Year'], errors='coerce')
        df['Rating'] = pd.to_numeric(df['Rating'], errors='coerce')
        df.dropna(subset=['Year', 'Rating'], inplace=True)
        df['Year'] = df['Year'].astype(int)
        print("Data cleaning complete. Rows with missing critical data have been removed.")
        print("\n---Movie Data Analysis---")
        #Question 1: what are the top 10 highest rated movies?
        top_10_movies = df.sort_values(by='Rating', ascending=False).head(10)
        print("\nQ1: Top 10 Highest Rated Movies: ")
        print(top_10_movies[['Title', 'Year', 'Rating']])
        #Q2: In which decade were the most movies released?
        #we create a decade column by mathematical floor division on the year
        df['decade'] = (df['Year']//10)*10
        movies_per_decade = df['decade'].value_counts().sort_index()
        top_decade = movies_per_decade.idxmax()
        print(f"\nQ2: The decade with the most movie releases was: {top_decade}s")
        print("Movies per decade:")
        print(movies_per_decade)
        #Q3: What are the most common movie genres?
        #The genre column can have multiple genres separated by commas.
        #we need to split them, collect all and then count.
        all_genres = df['Genre'].str.split(", ").explode()
        top_genres = all_genres.value_counts().head(10)
        print("\nQ3: Top 10 Most Common Movie Genres: ")
        print(top_genres)
        #Q4: How has the average movie rating changed over the decades?
        avg_rating_per_decade = df.groupby('decade')['Rating'].mean().round(2)
        print("\nQ4: Average Movie Rating per Decade: ")
        print(avg_rating_per_decade)
    except FileNotFoundError:
        print(f"Error: The file {DATA_FILE} was not found. Please make sure it's in the same folder.")
    except Exception as e:
        print(f"An error occurred: {e}")


if __name__ == "__main__":
    explore_movie_dataset(DATA_FILE)