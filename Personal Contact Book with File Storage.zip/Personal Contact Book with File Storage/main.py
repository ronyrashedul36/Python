import csv

import os

contacts_file = 'contacts.csv'

header = ['name', 'phone', 'email']

def load_contacts():
    contacts = []

    if os.path.exists(contacts_file):
        with open(contacts_file, mode='r', newline='') as file:
            reader = csv.DictReader(file)
            for row in reader:
                contacts.append(row)
    return contacts

def save_contacts(contacts):
    with open(contacts_file, mode='w', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=header)
        writer.writeheader()
        writer.writerows(contacts)


def view_contacts(contacts):
    print("\n---Your Contacts---")

    if not contacts:
        print('your contact book is empty.')
    else:
        for i,contact in enumerate(contacts, start=1):
            print(f'{i} Name: {contact["name"]}, phone: {contact["phone"]}, Email: {contact["email"]}')
    print("----------------\n")


def add_contact(contacts):
    print("\n--- Add a new Contact ---")
    name = input("Enter name: ")
    phone = input("Enter phone number: ")
    email = input("Enter email address: ")

    new_contact = {
        "name" : name,
        "phone" : phone,
        "email" : email
    }

    contacts.append(new_contact)
    print(f"Contact for {name} added successfully!\n")

def main_menu():
    print("--- Contact Book Menu---")
    print("1. View all contacts")
    print("2. Add a new contact")
    print("3. Exit")

def main():
    all_contacts = load_contacts()

    while True:
        main_menu()
        choice = input("Please enter your choice (1,2, or 3): ")
        if choice == '1':
            view_contacts(all_contacts)
        elif choice == '2':
            add_contact(all_contacts)
        elif choice == '3':
            print("Thank you for using the Contact Book. Goodbye!")
            break
        else:
            print("Invalid choice. Please try again.\n")

if __name__ == "__main__":
    main()