import pandas as pd
import numpy as np  # To handle 'N/A' values


def clean_product_data(input_file, output_file):
    """
    Loads a dirty e-commerce product dataset, cleans it, and saves the
    clean version.
    """
    try:
        # Step 1: Load the messy dataset, treating 'N/A' as a missing value
        print(f"Loading data from '{input_file}'...")
        # We tell pandas that 'N/A' should also be considered a NaN
        df = pd.read_csv(input_file, na_values=['N/A'])
        print("Initial data loaded. Shape:", df.shape)
        print("\n--- Initial Data Info ---")
        df.info()
        print("\nMissing values before cleaning:")
        print(df.isnull().sum())

        # Step 2: Handle Duplicate Rows based on ProductID
        print("\n--- Step 2: Removing duplicate products ---")
        initial_rows = len(df)
        df.drop_duplicates(subset=['ProductID'], keep='first', inplace=True)
        print(f"Removed {initial_rows - len(df)} duplicate product(s).")
        print("Current shape:", df.shape)

        # Step 3: Clean and Standardize Text Columns
        print("\n--- Step 3: Standardizing 'Category' column ---")
        df['Category'] = df['Category'].str.strip().str.title()
        print("Cleaned 'Category' column.")

        # Step 4: Clean and Convert Numeric-like Columns
        print("\n--- Step 4: Cleaning numeric columns ---")

        # Clean 'Price' column
        df['Price'] = df['Price'].astype(str).str.replace(r'[\$, USD]', '', regex=True).str.strip()
        df['Price'] = pd.to_numeric(df['Price'], errors='coerce')

        # Clean 'Stock' column
        # Using .str.extract with a regular expression to find the first sequence of digits
        df['Stock'] = df['Stock'].astype(str).str.extract(r'(\d+)').astype(float)

        print("Cleaned 'Price' and 'Stock' columns.")

        # Step 5: Handle Missing Values (Imputation)
        print("\n--- Step 5: Handling remaining missing values ---")
        # For 'Price', fill with the median
        median_price = df['Price'].median()
        df['Price'] = df['Price'].fillna(median_price)
        print(f"Filled missing 'Price' with median: ${median_price:.2f}")

        # For 'Rating', fill with the mean
        mean_rating = df['Rating'].mean()
        df['Rating'] = df['Rating'].fillna(mean_rating)
        print(f"Filled missing 'Rating' with mean: {mean_rating:.2f}")

        # For 'Stock', fill with 0, assuming no stock information means out of stock
        df['Stock'] = df['Stock'].fillna(0)
        print("Filled missing 'Stock' with 0.")

        # Step 6: Final Data Type Conversion
        print("\n--- Step 6: Converting columns to appropriate types ---")
        df['Stock'] = df['Stock'].astype(int)
        df['Rating'] = df['Rating'].round(2)  # Round rating to 2 decimal places

        # Final check
        print("\n--- Final Data Info ---")
        df.info()
        print("\nCleaned DataFrame head:")
        print(df.head())

        # Step 7: Save the cleaned data to a new CSV file
        df.to_csv(output_file, index=False)
        print(f"\nSuccessfully cleaned data and saved to '{output_file}'.")

    except FileNotFoundError:
        print(f"Error: The input file '{input_file}' was not found.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")


# --- Main execution block ---
if __name__ == "__main__":
    INPUT_CSV = "dirty_products.csv"
    OUTPUT_CSV = "clean_products.csv"
    clean_product_data(INPUT_CSV, OUTPUT_CSV)