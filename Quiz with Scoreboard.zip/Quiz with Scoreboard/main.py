import csv
import os

SCOREBOARD_FILE = 'scores.csv'

questions = [
    {
        'question' : 'what is the capital of japan?',
        'options' : ['A. Beijing', 'B. Seoul', 'C. Tokyo', 'D. Bangkok'],
        'answer' : 'C'
    },
    {
        'question' : 'which is the largest planet in our solar system?',
        'options' : ['A. Earth', 'B. Jupiter', 'C. Mars', 'D. Saturn'],
        'answer' : 'B'
    },
    {
        'question' : 'what is the chemical symbol for water?',
        'options' : ['A. o2', 'B. H2O', 'C. CO@', 'D. NaCl'],
        'answer' : 'B'
    },
    {
        'question' : 'how many continents are there on earth?',
        'options' : ['A. 5', 'B. 6', 'C. 7', 'D. 8'],
        'answer' : 'C'
    }
]

def run_quiz():
    score = 0

    print("\n---The Quiz Begins!---")
    for q in questions:
        print("\n-------------")
        print(q['question'])
        for option in q['options']:
            print(option)
        user_answer = input("Enter your answer (A,B,C or D): ").upper()
        if user_answer == q['answer']:
            print("Correct! You got 1 point.")
            score += 1
        else:
            print(f"Wrong! The Correct answer was {q['answer']}")
    print("\n---Quiz Over---")
    print(f"Your final score is: {score} out of {len(questions)}")
    return  score

def save_score(name, score):
    with open(SCOREBOARD_FILE, mode='a', newline='') as file:
        writer = csv.writer(file)
        if os.path.getsize(SCOREBOARD_FILE) == 0:
            writer.writerow(['name', 'score'])
        writer.writerow([name, score])
    print("Your score has been saved to the leaderboard!")

def show_leaderboard():
    print("\n---LEADERBOARD (TOP 5) ---")
    if not os.path.exists(SCOREBOARD_FILE):
        print("No scores recorded yet. Be the first!")
        return
    all_scores = []
    with open(SCOREBOARD_FILE, mode='r') as file:
        reader = csv.reader(file)
        header = next(reader)
        for row in reader:
            all_scores.append([row[0], int(row[1])])
    if not all_scores:
        print("The leaderboard is empty.")
        return
    sorted_scores = sorted(all_scores, key=lambda item:item[1], reverse = True)
    for i, entry in enumerate(sorted_scores[:5], start = 1):
        name = entry[0]
        score = entry[1]
        print(f"{i}. {name} - score: {score}")
    print("-----------------\n")

def main():
    while True:
        print("\nWelcome to the Quiz Game")
        print("1. Start a New Quiz")
        print("2. View Leaderboard")
        print("3. Exit")
        choice = input("Enter your choice (1, 2, or 3): ")
        if choice == "1":
            final_score = run_quiz()
            player_name = input("Enter your name to save your score: ")
            save_score(player_name, final_score)
        elif choice == "2":
            show_leaderboard()
        elif choice == "3":
            print("Thanks for playing. Goodbye!")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()