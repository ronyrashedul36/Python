import seaborn as sns

import matplotlib.pyplot as plt

import pandas as pd

df = sns.load_dataset('titanic')

print(df.head())

print(f"Shape of Data: {df.shape}")

print("\nData Info:")

df.info()

print("\nStatistical Summary: ")

print(df.describe())

print("\nMissing values count: ")

print(df.isnull().sum())

print(f"\nDuplicate Rows: {df.duplicated().sum()}")

#Univariate Analysis
#categorical variable
sns.countplot(data=df, x='survived')

plt.title('Distribution of Survival')

plt.show()

#Numerical Variable

sns.histplot(data=df, x='age', kde=True, bins=30)

plt.title('Age Distribution')

plt.show()

sns.boxplot(data=df, x='fare')

plt.title('Fare Boxplot (Check Outliers)')

plt.show()

#Bivariate Analysis

sns.boxplot(data=df, x='survived', y='age')

plt.title('Age vs Survival')

plt.show()

sns.countplot(data=df, x='survived', hue='sex')

plt.title('Survival Count by Sex')

plt.show()

numeric_df = df.select_dtypes(include=['number'])

corr_matrix = numeric_df.corr()

plt.figure(figsize=(10,8))

sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', fmt='.2f')

plt.title('Correlation Matrix')

plt.show()