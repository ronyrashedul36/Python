import pandas as pd

def analyze_ecommerce_data(customers_file, products_file, orders_file, report_file):
    try:
        print("Loading data...")
        df_customers = pd.read_csv(customers_file)
        df_products = pd.read_csv(products_file)
        df_orders = pd.read_csv(orders_file)
        print("Datasets loaded!")
        print("Merging data...")
        df_merged = pd.merge(df_orders, df_products, on='ProductID', how='left')
        df_master = pd.merge(df_merged, df_customers, on='CustomerID', how='left')
        print("Dataset merged!")
        print("\n --- Master DataFrame Head ---")
        print(df_master.head())
        df_master['TotalSale'] = df_master['Quantity'] * df_master['Price']

        print("\nPerforming analysis!")
        customer_spending = df_master.groupby(['CustomerID', 'CustomerName'])['TotalSale'].sum().sort_values(ascending=False)
        city_sales = df_master.groupby('City')['TotalSale'].sum().sort_values(ascending=False)
        category_revenue = df_master.groupby(['Category'])['TotalSale'].sum().sort_values(ascending=False)
        product_quantity = df_master.groupby(['ProductName', 'Category'])['Quantity'].sum().sort_values(ascending=False)
        print(f"Generating report...")
        with open(report_file, 'w') as f:
            f.write("--- E-commerce Sales Analysis ---\n")
            f.write("="*40+"\n\n")
            f.write("---Top 5 Customers by spending ---\n")
            f.write(customer_spending.head().to_string())
            f.write("\n\n")
            f.write("---Total Sales by City ---\n")
            f.write(city_sales.to_string())
            f.write("\n\n")
            f.write("---  total revenue by product category ---")
            f.write(category_revenue.to_string())
            f.write("\n\n")
            f.write("--- Top 5 Best Selling Products (by Quantity) ---\n")
            f.write(product_quantity.head().to_string())
            f.write("\n\n")
        print("Report generated!")
    except FileNotFoundError as e:
        print(f"Error: {e}")
    except Exception as e:
        print(f"An error occured: {e}")


if __name__ == "__main__":
    CUSTOMERS_CSV = 'customers.csv'
    PRODUCTS_CSV = 'products.csv'
    ORDERS_CSV = 'orders.csv'
    REPORT_TXT = 'ecommerce_report.txt'

    analyze_ecommerce_data(CUSTOMERS_CSV, PRODUCTS_CSV, ORDERS_CSV, REPORT_TXT)